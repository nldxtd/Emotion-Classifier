## 程序复现方法
- 使用jupyter-lab
- 运行所有代码段
- 环境需要
> tensorflow 2.x\
> matplotlib\
> pydot\
> grapgviz

后面两个是用来画model的，如果无法复现可以看文件夹里已经画好的图片。

不想跑代码可以直接看`实验结果.pdf`里面已经跑好的结果。
